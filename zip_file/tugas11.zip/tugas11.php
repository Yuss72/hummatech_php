<?php
    // require
    // require biasanya digunakan untuk menyambungkan file lain ke dalam file php yang diinginkan, dan jika filenya tidak dapat ditemukan maka program akan berhenti.
    
    // include
    // hampir sama seperti require tapi jika file tidak ditemukan, php nya hanya muncul warning dn kode tetap berjalan.

    // include_once & require_once
    // sama seperti include dan require tetapi file yang dipanggil hanya akan berjalan satu kali di dalam file php tersebut
?>