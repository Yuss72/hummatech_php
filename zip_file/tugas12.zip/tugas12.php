<?php
    echo "<script>alert('Apakah anda bisa membuat ini?');</script>";
?>