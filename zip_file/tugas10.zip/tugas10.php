<?php
    echo strlen("Saya sedang belajar tipe data string"); // 36
?>