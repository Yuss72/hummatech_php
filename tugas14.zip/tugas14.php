<?php
    echo "<h1>Selamat Datang</h1>";
    echo "<p>Hari Ini Tanggal " . date("d F y h:i A") . "</p>";
?>