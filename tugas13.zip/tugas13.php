<?php
    $HurufBesar = "SAYA Sedang Belajar PHP dENGAN VIsual sTUDIO";
    $hurufkecil = strtolower($HurufBesar);

    echo $hurufkecil;
?>