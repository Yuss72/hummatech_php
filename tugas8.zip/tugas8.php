<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
</head>
<body>
    <form action="" method="$_POST">
        <input type="text" name="nama_depan" id="nama_depan" required>
        <input type="text" name="nama_belakang" id="nama_belakang" required>
        <input type="submit" value="daftar">
    </form>
</body>
</html>