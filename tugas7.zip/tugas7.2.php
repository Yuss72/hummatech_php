<?php
    $nama = $_GET['nama'];
    $usia = $_GET['usia'];

    echo "Selamat Datang, " . $nama;
    echo "<br>";
    echo "Usia Anda adalah " . $usia . " tahun";
?>