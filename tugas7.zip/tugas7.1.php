<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="tugas7.2.php" method="GET">
        <label for="nama">Nama: </label>
        <input type="text" name="nama" id="nama"><br><br>
        <label for="usia">Usia: </label>
        <input type="usia" name="usia" id="usia"><br><br>
        <input type="submit" value="Kirim">
    </form>
</body>
</html>